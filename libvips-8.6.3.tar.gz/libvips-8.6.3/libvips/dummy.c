/* mac os x libtool hates empty link sections in convenience libraries
 */
const int im__dummy_value = 42;
